#!/bin/bash
HELLO=Hello
function hello {
local HELLO=World
echo $HELLOecho $HELLOecho $HELLOecho $HELLO
}
echo $HELLO
hello
local HELLO=World
echo $HELLOecho $HELLOecho $HELLOecho $HELLO
}
echo $HELLO
hello
local HELLO=World
echo $HELLOecho $HELLOecho $HELLOecho $HELLO
}
echo $HELLO
hello
